/**
 * Collection control
 * Author: Guriev Eugen
 */
jQuery( document ).ready(
	function(){
		if ( jQuery( '.cherry-infinite-container' ).length ) {
			jQuery( '.cherry-infinite-container' ).Ininite_Control();
		}
	}
);