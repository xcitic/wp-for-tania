<?php get_header( pilates_template_base() ); ?>

	<?php do_action( 'pilates_render_widget_area', 'full-width-header-area' ); ?>

	<?php pilates_site_breadcrumbs(); ?>

	<div class="site-content_wrap">

		<?php do_action( 'pilates_render_widget_area', 'before-content-area' ); ?>

			<div id="primary">

				<?php do_action( 'pilates_render_widget_area', 'before-loop-area' ); ?>

				<main id="main" class="site-main" role="main">

					<?php include pilates_template_path(); ?>

				</main><!-- #main -->

				<?php do_action( 'pilates_render_widget_area', 'after-loop-area' ); ?>

			</div><!-- #primary -->

		<?php do_action( 'pilates_render_widget_area', 'after-content-area' ); ?>

	</div><!-- .container -->

	<?php do_action( 'pilates_render_widget_area', 'after-content-full-width-area' ); ?>

<?php get_footer( pilates_template_base() ); ?>
