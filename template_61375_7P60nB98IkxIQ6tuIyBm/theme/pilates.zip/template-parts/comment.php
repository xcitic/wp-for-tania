<div class="comment-body__holder">
	<div class="comment-body__author vcard">
		<?php echo pilates_comment_author_avatar(); ?>
	</div>
	<div class="comment-body__comment">
		<div class="comment-meta">
			<div class="comment-metadata">
		<?php printf( '<span class="posted-by">%s</span>%s', esc_html__( 'by ', 'pilates' ), pilates_get_comment_author_link() ); ?>
		<?php echo pilates_get_comment_date( array( 'format' => 'M d, Y' ) ); ?>
	</div>
		</div>
		<div class="comment-content">
			<?php echo pilates_get_comment_text(); ?>
		</div>
	</div>
</div>
<div class="reply">
	<?php echo pilates_get_comment_reply_link( array( 'reply_text' => '<i class="material-icons">reply</i>' ) ); ?>
</div>