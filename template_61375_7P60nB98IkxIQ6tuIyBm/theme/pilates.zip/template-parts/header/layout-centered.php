<?php
/**
 * Template part for centered Header layout.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Pilates
 */
?>

<div class="header-container__flex">
	<div class="header-container__center">
		<div class="site-branding">
			<?php pilates_header_logo() ?>
			<?php pilates_site_description(); ?>
		</div>

		<?php pilates_main_menu(); ?>
	</div>

	<?php pilates_social_list( 'header' ); ?>
</div>