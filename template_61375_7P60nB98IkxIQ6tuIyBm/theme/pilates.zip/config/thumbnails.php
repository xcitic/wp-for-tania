<?php
/**
 * Thumbnails configuration.
 *
 * @package Pilates
 */

add_action( 'after_setup_theme', 'pilates_register_image_sizes', 5 );
function pilates_register_image_sizes() {
	set_post_thumbnail_size( 540, 510, true );

	// Registers a new image sizes.
	add_image_size( 'pilates-thumb-s', 150, 150, true );
	add_image_size( 'pilates-thumb-m', 400, 400, true );
	add_image_size( 'pilates-thumb-594-427', 594, 427, true );
	add_image_size( 'pilates-thumb-l', 1280, 510, true );
	add_image_size( 'pilates-thumb-xl', 1920, 1080, true );
	add_image_size( 'pilates-author-avatar', 512, 512, true );

	add_image_size( 'pilates-thumb-240-100', 240, 100, true );
	add_image_size( 'pilates-thumb-560-390', 560, 390, true );
}
